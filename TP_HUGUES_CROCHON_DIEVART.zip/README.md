# TP_Intergiciel

TP Intergiciel Kafka

## Rendu par

CROCHON Cécile
DIEVART Cyriaque
HUGUES Pierre
M2 TNSI FA

## Infos

La partie "haute" a été réalisé en JavaScript avec Node.JS. Pour l'utiliser il est nécessaire d'avoir Node installé sur sa machine et d'exécuter les fonctions suivantes pour compiler et démarrer le code :

- npm i
- node index.js

Elle créé les topics nécessaires avant de commencer l'exécution des CS1/PR1.

La partie "basse" a été réalisée en Java. Il suffit de lancer la fonction main contenue dans console.java.

## Attention

Il faudra peut-être modifié les informations de connexion à la BDD et aux brokers pour correspondre à votre machine.

Partie haute : config/config.json
Partie basse : src/main/java/console.java (L32 pour le broker et L74 pour la BDD)